import { useState } from "react";


function Imc(){

    const [nome, setNome] = useState("maria")
    const [peso, setPeso] = useState(0)
    const [altura, setAltura] = useState (0)


    let imc = (peso) / (altura * altura)
    return(
        <div>
            <label>Informe seu nome:</label>
            <input value={nome} type="text"  onChange={() => setNome(event.target.value)}/>

            <label>Informe seu peso:</label>
            <input value={peso} type="number"  onChange={() => setPeso(parseFloat(event.target.value))}/>

            <label>Informe sua altura:</label>
            <input value={altura} type="number"  onChange={() => setAltura(parseFloat(event.target.value))}/>

            <h2>Seu nome é:{nome}</h2>
            <h2>Seu IMC é: {imc}</h2>

            <h2>Sua classificação é {imc <= 18.5 ? "Baixo peso" : imc <= 24.9 ? "Peso normal" : imc <= 29.9 ? "Sobrepeso" :  imc <= 30.0 ? "Obesidade grau I" :  imc <= 35 ? "Obesidade grau II" :  "Obesidade grau III" }</h2>




        </div>
    )

}

export default Imc;