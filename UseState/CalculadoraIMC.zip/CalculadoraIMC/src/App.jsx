import Imc from "./Imc"

function App() {

  return (
    <Imc/>
  )

}

export default App
