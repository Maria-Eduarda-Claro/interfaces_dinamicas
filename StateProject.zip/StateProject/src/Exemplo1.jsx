import { useState } from "react";

function Exemplo1(){

const [contar, setContar] = useState(0);
 console.log(contar);

// criando uma função com arrow function
  const incrementar = () => {
    // contar = contar + 1;
    setContar(contar + 1)
    console.log(contar)

  }



  return(
    <div>
      <h1>Hello Js</h1>

      <button onClick={incrementar}>Incrementar</button>

      <p>O valor é {contar}</p>
    </div>
    
  )
}

export default Exemplo1;