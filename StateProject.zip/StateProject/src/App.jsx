import { useState } from "react";
import Exemplo2 from "./Exemplo2";

function App() {

 return(
    <Exemplo2/>
 )

  
}

export default App
