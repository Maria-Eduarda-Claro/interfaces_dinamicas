import objeto from './Info.module.css'

function Info(){
    return(
        <div className={objeto.box1}>

        </div>
    )
}

export default Info; 