import objeto from './Header.module.css'

function Header(){
    return(
        <div className={objeto.estilo}>

        </div>
    )
}

export default Header;