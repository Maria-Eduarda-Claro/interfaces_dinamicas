import Header from "./Header"
import Info from './Info'
import Footer from './Footer'

function App(){
  return(
    <div>
      <Header/>
     
      <div>
        <Info/> 
        <Info/>
        <Info/>
      </div>
      <div>
       <Footer/>
      </div>

    </div>
  )
}

export default App;