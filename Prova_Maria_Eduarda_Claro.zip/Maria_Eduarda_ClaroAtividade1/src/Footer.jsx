import objeto from './Footer.module.css'


function Footer(){
    return(
        <div className={objeto.footer}>

        </div>
    )

}

export default Footer; 