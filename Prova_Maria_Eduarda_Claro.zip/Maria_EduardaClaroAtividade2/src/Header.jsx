import objeto from './Header.module.css'

function Header(props){
    return(
     
        <div className={objeto.check1}>{props.mensagem}</div>
      
    )
}

export default Header; 