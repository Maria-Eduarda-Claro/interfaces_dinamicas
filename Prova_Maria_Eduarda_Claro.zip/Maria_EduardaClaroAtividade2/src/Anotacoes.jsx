import objeto from './Header.module.css'
import Header from "./Header";

function Anotacoes(){
    return(
        <main>
        <div className={objeto.body}></div>
        <div className={objeto.header}>Anotações</div>
        <div className={objeto.box}>
            <Header mensagem='Fazer Atividades de React.'/>
            <Header mensagem='Tomar mais agua durante o dia.'/>
            <Header mensagem='HTML não é linguagem de programação'/>
            <Header mensagem='Semana de prova'/>
            <Header mensagem='O que é dormir?'/>
        </div>
        </main>
    )
}

export default Anotacoes;