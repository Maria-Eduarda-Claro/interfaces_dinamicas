import Anotacoes from "./Anotacoes";
import Header from "./Header";


function App(){
  return(
    <div>
      <Anotacoes/>
    </div>
  )
}

export default App; 