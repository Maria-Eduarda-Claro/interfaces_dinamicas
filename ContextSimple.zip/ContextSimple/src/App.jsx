

import { createContext, useContext, useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

const contextExemplo = createContext();

function App() {
  const [nome, setNome] = useState('Carlos')
  const [sobrenome, setSobrenome] = useState ('Silva')
  const [idade, setIdade] = useState (12)

  return (
    <>
  
    <contextExemplo.Provider value={{nome, sobrenome, setNome, idade}}>
      <ComponenteFilho/>
    </contextExemplo.Provider>


    <ComponenteTataraneto/>

    </>



    
  )
}

function ComponenteFilho(){

const {setNome} = useContext(contextExemplo)

setNome('João')

  return(
    <>
      <ComponenteNeto/>
    <ComponenteBisneto/>
    </>
    
  )
   
}

function ComponenteNeto(props){

 const {nome, sobrenome} =  useContext(contextExemplo);

 console.log(nome)

  return <h1>O nome da pessoa é {nome} {sobrenome}</h1>

}

function ComponenteTataraneto(){

const {nome} = useContext (contextExemplo)

return <div>Nome dentro do tataraneto</div>


}



function ComponenteBisneto(){
  const {idade} = useContext(contextExemplo);
  return <h2> {idade} anos </h2>
}

export default App
