
function olaJavaScript(){

    /*
    Formas de criar variaveis
    var
    ley
    const
    */

    //document acessa o DOM do html  //DOM = documento do html
    let login = document.getElementById('login').value;
    let password = document.getElementById('password').value;

    if(login == 'cesul' && password == 'cesul'){

        alert('Login realizado com sucesso!')
    }else{
        alert('Problema ao realizar login')
    }


    alert(login)
}