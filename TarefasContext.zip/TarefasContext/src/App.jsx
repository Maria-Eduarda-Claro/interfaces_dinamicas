
import { useContext } from 'react'
import './App.css'
import Header from './componenents/Header'
import { ThemeContext } from './contexts/ThemeContext'

function App() {

  const {theme} = useContext(ThemeContext)
  

  return (
    <main  className={`${ theme !== 'dark' ?  'dark' : '' }`}>
      <Header/>
    </main>
  )
}

export default App
