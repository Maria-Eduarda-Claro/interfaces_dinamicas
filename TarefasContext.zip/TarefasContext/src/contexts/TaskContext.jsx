import { createContext, useState } from "react";   // CRIAÇÃO DE CONTEXTO PADRÃO

export const TaskContext = createContext();

export const TaskProvider = ({children}) =>{

    const [listarTarefas, setListaTarefas] = useState ([{nomeTerada: 'Teste'}]);

    function cadastrarTarefa(tarefa){

        setListaTarefas([tarefa, ...listarTarefas])
    }

   return <TaskContext.Provider  value ={({listarTarefas, cadastrarTarefa})}>{children}</TaskContext.Provider>
}